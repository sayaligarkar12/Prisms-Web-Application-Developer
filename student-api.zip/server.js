import express from "express";
import fs from "fs-extra";
import cors from "cors";

const app = express();
app.use(express.json());
app.use(cors());

const FILE = "./students.json";

app.post("/register", async (req, res) => {
  try {
    const { name, email, phone, course } = req.body;

    if (!name || !email || !phone || !course) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const data = await fs.readJSON(FILE);

    const newStudent = {
      id: Date.now(),
      name,
      email,
      phone,
      course
    };

    data.push(newStudent);
    await fs.writeJSON(FILE, data, { spaces: 2 });

    res.json({ message: "Student registered successfully", student: newStudent });

  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

app.get("/students", async (req, res) => {
  try {
    const data = await fs.readJSON(FILE);
    res.json(data);
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
