# Student Registration API (Node.js + Express)

## How to Run
1. Install dependencies:
```
npm install
```

2. Start server:
```
node server.js
```

3. Test in Postman:
- **POST** http://localhost:5000/register  
  Body (JSON):
```
{
  "name": "Sayali",
  "email": "sayali@gmail.com",
  "phone": "9876543210",
  "course": "BCA"
}
```

- **GET** http://localhost:5000/students
